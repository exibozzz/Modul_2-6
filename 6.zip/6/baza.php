<?php



$check_send = isset($_POST["search"]);
if(!$check_send ) {die( "Niste uneli pretragu.");}

$username = trim($_POST["search"]);

if($username == "") {die("Niste uneli pretragu.");}

$username = strtolower($username);
$lenght_search = strlen($_POST["search"]);

if($lenght_search < 3 || $lenght_search > 10 ) {die ("Ime mora da sadrži 3-10 karaktera");}

$person = ["nikola", "teodora", "milica", "marko", "aleksandra", "jovan", "milica", "petar", "anja"];



if(in_array($username, $person)) {echo "Pronadjeni su rezultati $username";}

?>









