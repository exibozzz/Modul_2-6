<?php







?>


<!DOCTYPE html>
<html lang="en">
<head>
    <title>#6 POST</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    
<holder class="form_holder" >
    <form class="form" method="POST" action="baza.php" >
        <input type="text" name="search" id="search" placeholder="Unesite ime za pretragu.">
        <button>Check</button>
    </form>
</holder>

    
</body>
</html>